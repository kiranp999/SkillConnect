import React, { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import MainLayout from '../layouts/MainLayout';
import { useAuth } from '../context/AuthContext';
import { useBooking } from '../context/BookingContext';
import { useToast } from '../context/ToastContext';
import { FiStar, FiCheck, FiSend, FiArrowLeft } from 'react-icons/fi';

const ReviewPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { bookings, addReview, loading } = useBooking();
  const { showToast } = useToast();
  const booking = bookings.find((item) => String(item.id) === String(id));
  const [rating, setRating] = useState(5);
  const [hoverRating, setHoverRating] = useState(0);
  const [comment, setComment] = useState('');
  const [selectedTags, setSelectedTags] = useState(['Punctual', 'Clean Work']);
  const [submitting, setSubmitting] = useState(false);
  const tags = ['Punctual', 'Clean Work', 'Polite', 'Reasonable Price', 'Expert Diagnosis', 'Highly Recommended'];

  if (loading) return <MainLayout><div className="container py-5 text-center"><div className="spinner-border text-primary" /></div></MainLayout>;
  if (!booking) return <MainLayout><div className="container py-5 text-center"><h5>Booking Not Found</h5><button onClick={() => navigate(-1)} className="btn btn-primary-custom mt-3">Go Back</button></div></MainLayout>;
  if (booking.status !== 'Completed') return <MainLayout><div className="container py-5 text-center"><h5>Review unavailable</h5><p className="text-muted">You can review this worker after the service is completed.</p><button onClick={() => navigate('/bookings')} className="btn btn-primary-custom">Back to Bookings</button></div></MainLayout>;

  const submit = async (event) => {
    event.preventDefault();
    if (!comment.trim()) return showToast('Please enter a comment.', 'error');
    setSubmitting(true);
    try {
      await addReview({ bookingDbId: booking.dbId, rating, comment: `${selectedTags.join(', ')}${selectedTags.length ? ' - ' : ''}${comment.trim()}` });
      showToast('Review submitted successfully.', 'success');
      navigate('/bookings');
    } catch (error) {
      showToast(error.response?.data?.error || error.message || 'Unable to submit review.', 'error');
    } finally { setSubmitting(false); }
  };

  return <MainLayout><section className="py-5"><div className="container" style={{ maxWidth: 680 }}><button onClick={() => navigate(-1)} className="btn btn-sm btn-outline-secondary mb-4"><FiArrowLeft className="me-1" /> Back</button><div className="card-custom p-4 p-md-5 text-center"><h3 className="fw-extrabold text-main mb-1">Rate Your Service</h3><p className="text-muted small mb-4">Share your completed service experience with the community.</p><div className="p-3 bg-primary-subtle rounded-4 d-inline-flex align-items-center gap-3 mb-4 text-start"><div className="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center fw-bold" style={{ width: 56, height: 56 }}>{booking.workerName?.charAt(0)}</div><div><h6 className="fw-bold mb-0 text-main">{booking.workerName}</h6><span className="badge-custom badge-primary mt-1">{booking.workerCategory}</span></div></div><form onSubmit={submit}><div className="mb-4"><label className="form-label small fw-bold text-main d-block mb-2">Overall rating</label><div className="d-flex justify-content-center gap-2">{[1,2,3,4,5].map((star) => <button key={star} type="button" onMouseEnter={() => setHoverRating(star)} onMouseLeave={() => setHoverRating(0)} onClick={() => setRating(star)} className="btn border-0 p-1 bg-transparent"><FiStar size={36} style={{ color: star <= (hoverRating || rating) ? '#f59e0b' : '#cbd5e1', fill: star <= (hoverRating || rating) ? '#f59e0b' : 'transparent' }} /></button>)}</div><div className="text-warning fw-bold mt-2">{rating} / 5</div></div><div className="mb-4"><label className="form-label small fw-bold text-main d-block mb-2">Highlights</label><div className="d-flex flex-wrap justify-content-center gap-2">{tags.map((tag) => <button key={tag} type="button" onClick={() => setSelectedTags((prev) => prev.includes(tag) ? prev.filter((x) => x !== tag) : [...prev, tag])} className={`btn btn-sm rounded-pill px-3 ${selectedTags.includes(tag) ? 'btn-primary' : 'btn-outline-secondary'}`}>{selectedTags.includes(tag) && <FiCheck className="me-1" />}{tag}</button>)}</div></div><textarea rows={4} className="form-control form-control-custom mb-4" placeholder="Describe the quality of work..." value={comment} onChange={(e) => setComment(e.target.value)} required /><button disabled={submitting} className="btn btn-primary-custom w-100 py-3 justify-content-center">{submitting ? 'Submitting...' : <>Submit Review <FiSend size={18} /></>}</button></form></div></div></section></MainLayout>;
};
export default ReviewPage;
