import React, { useState } from 'react';
import MainLayout from '../layouts/MainLayout';
import { useBooking } from '../context/BookingContext';
import BookingCard from '../components/cards/BookingCard';
import { FiCalendar, FiFilter, FiCheckCircle, FiClock, FiXCircle } from 'react-icons/fi';

const BookingHistoryPage = () => {
  const { bookings, cancelBooking } = useBooking();
  const [filterStatus, setFilterStatus] = useState('All');

  const filteredBookings = bookings.filter((b) => {
    if (filterStatus === 'All') return true;
    return b.status.toLowerCase() === filterStatus.toLowerCase();
  });

  return (
    <MainLayout>
      <section className="py-5">
        <div className="container" style={{ maxWidth: '960px' }}>
          <div className="d-flex flex-column flex-sm-row align-items-sm-center justify-content-between mb-4 gap-3">
            <div>
              <h2 className="fw-extrabold text-main m-0">Booking History</h2>
              <span className="text-muted small">View all your past and upcoming local service appointments</span>
            </div>

            {/* Filter Pills */}
            <div className="d-flex p-1 bg-body-secondary rounded-3">
              {['All', 'Pending', 'Accepted', 'Estimate Submitted', 'Estimate Rejected', 'Estimate Approved', 'Completed', 'Cancelled'].map((st) => (
                <button
                  key={st}
                  onClick={() => setFilterStatus(st)}
                  className={`btn btn-sm fw-bold px-3 py-1.5 rounded-3 ${
                    filterStatus === st ? 'btn-primary shadow-sm' : 'text-muted'
                  }`}
                >
                  {st}
                </button>
              ))}
            </div>
          </div>

          {filteredBookings.length > 0 ? (
            filteredBookings.map((booking) => (
              <BookingCard
                key={booking.id}
                booking={booking}
                onStatusUpdate={(id, status) => status === 'Cancelled' && cancelBooking(id)}
              />
            ))
          ) : (
            <div className="card-custom p-5 text-center text-muted">
              <FiCalendar size={42} className="mb-2 text-primary opacity-50" />
              <h5>No bookings found for "{filterStatus}" status.</h5>
            </div>
          )}
        </div>
      </section>
    </MainLayout>
  );
};

export default BookingHistoryPage;
