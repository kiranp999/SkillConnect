import React from 'react';
import { Link } from 'react-router-dom';
import { FiCalendar, FiClock, FiMapPin, FiFileText, FiStar } from 'react-icons/fi';
import { getStatusBadgeClass } from '../../utils/helpers';

const BookingCard = ({ booking, onStatusUpdate }) => {
  if (!booking) return null;
  const hasEstimate = Number(booking.estimatedAmount) > 0 && booking.estimateBreakdown?.length > 0;
  const canCancel = ['Pending', 'Accepted', 'Estimate Submitted', 'Estimate Rejected', 'Estimate Approved'].includes(booking.status);

  return (
    <div className="card-custom p-4 mb-3">
      <div className="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3 pb-3 border-bottom">
        <div className="d-flex align-items-center gap-3">
          {booking.workerAvatar ? <img src={booking.workerAvatar} alt={booking.workerName} className="rounded-circle object-fit-cover border border-2 border-primary" style={{ width: '54px', height: '54px' }} /> : <div className="rounded-circle bg-primary-subtle text-primary d-flex align-items-center justify-content-center fw-bold" style={{ width: '54px', height: '54px' }}>{booking.workerName?.charAt(0)}</div>}
          <div>
            <div className="d-flex align-items-center gap-2"><span className="fw-bold text-muted small">#{booking.id}</span><span className={`badge-custom ${getStatusBadgeClass(booking.status)}`}>{booking.status}</span></div>
            <h6 className="fw-bold mb-0 text-main mt-1">{booking.workerName}</h6>
            <span className="text-primary small fw-semibold">{booking.workerCategory}</span>
          </div>
        </div>
        <div className="text-md-end">
          <span className="text-muted small d-block">{hasEstimate ? 'Approved/Submitted Estimate' : 'Estimate'}</span>
          <span className="fs-5 fw-bold text-success">{hasEstimate ? `₹${booking.estimatedAmount.toFixed(2)}` : 'Pending worker inspection'}</span>
        </div>
      </div>

      <div className="row g-3 my-2 text-main small">
        <div className="col-md-4"><FiCalendar className="me-2 text-primary" /><strong>Date:</strong> {booking.date}</div>
        <div className="col-md-4"><FiClock className="me-2 text-primary" /><strong>Time:</strong> {booking.timeSlot}</div>
        <div className="col-md-4 text-truncate"><FiMapPin className="me-2 text-primary" /><strong>Location:</strong> {booking.address}</div>
      </div>

      <p className="text-muted small bg-body-secondary p-2.5 rounded-3 my-2"><strong>Service Details:</strong> {booking.serviceDetails}</p>

      <div className="d-flex flex-wrap align-items-center justify-content-between pt-3 gap-2">
        <Link to={`/booking/${booking.id}/estimate`} className="btn btn-sm btn-outline-custom"><FiFileText size={14} /> View Status & Estimate</Link>
        {booking.status === 'Completed' && <Link to={`/booking/${booking.id}/review`} className="btn btn-sm btn-warning text-dark fw-bold"><FiStar size={14} /> Leave Review</Link>}
        {canCancel && <button onClick={() => onStatusUpdate?.(booking.id, 'Cancelled')} className="btn btn-sm btn-outline-danger">Cancel Booking</button>}
      </div>
    </div>
  );
};

export default BookingCard;
