from django.urls import path
from dashboard.views import (
    CustomerDashboardView,
    WorkerDashboardView,
    AdminDashboardView
)

urlpatterns = [
    path('customer/', CustomerDashboardView.as_view(), name='dashboard-customer'),
    path('worker/', WorkerDashboardView.as_view(), name='dashboard-worker'),
    path('admin/', AdminDashboardView.as_view(), name='dashboard-admin'),
]
