from datetime import timedelta

from django.db.models import Sum
from django.utils import timezone
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from bookings.models import Booking
from bookings.serializers import BookingSerializer
from core.permissions import IsAdminUserRole, IsCustomer, IsWorker
from customers.models import Customer
from reviews.models import Review
from workers.models import Worker
from workers.serializers import WorkerSerializer


class CustomerDashboardView(APIView):
    permission_classes = [IsCustomer]

    def get(self, request):
        customer = getattr(request.user, 'customer_profile', None)
        if not customer:
            return Response({'error': 'Customer profile not found.'}, status=status.HTTP_404_NOT_FOUND)

        all_bookings = Booking.objects.filter(customer=customer)
        active_statuses = [
            Booking.Status.PENDING,
            Booking.Status.ACCEPTED,
            Booking.Status.ESTIMATE_SUBMITTED,
            Booking.Status.ESTIMATE_REJECTED,
            Booking.Status.ESTIMATE_APPROVED,
        ]
        upcoming = all_bookings.filter(booking_status__in=active_statuses)
        completed = all_bookings.filter(booking_status=Booking.Status.COMPLETED)
        recommended = Worker.objects.filter(
            verification_status=Worker.VerificationStatus.VERIFIED,
            availability=True,
        ).order_by('-average_rating', '-reviews_count')[:3]

        return Response({
            'total_bookings': all_bookings.count(),
            'active_bookings_count': upcoming.count(),
            'completed_bookings_count': completed.count(),
            'recommended_workers_count': recommended.count(),
            'upcoming_bookings': BookingSerializer(upcoming[:5], many=True).data,
            'recommended_workers': WorkerSerializer(recommended, many=True).data,
        })


class WorkerDashboardView(APIView):
    permission_classes = [IsWorker]

    def get(self, request):
        worker = getattr(request.user, 'worker_profile', None)
        if not worker:
            return Response({'error': 'Worker profile not found.'}, status=status.HTTP_404_NOT_FOUND)

        all_jobs = Booking.objects.filter(worker=worker)
        pending = all_jobs.filter(booking_status=Booking.Status.PENDING)
        active = all_jobs.filter(
            booking_status__in=[
                Booking.Status.ACCEPTED,
                Booking.Status.ESTIMATE_SUBMITTED,
                Booking.Status.ESTIMATE_REJECTED,
                Booking.Status.ESTIMATE_APPROVED,
            ]
        )
        completed = all_jobs.filter(booking_status=Booking.Status.COMPLETED)

        now = timezone.localtime()
        month_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        monthly_earnings = completed.filter(
            updated_at__gte=month_start
        ).aggregate(total=Sum('estimate_amount'))['total'] or 0

        weekly_data = []
        for offset in range(6, -1, -1):
            day = (now - timedelta(days=offset)).date()
            total = completed.filter(updated_at__date=day).aggregate(total=Sum('estimate_amount'))['total'] or 0
            weekly_data.append(float(total))

        return Response({
            'worker_name': worker.full_name,
            'is_available': worker.availability,
            'is_verified': worker.verification_status == Worker.VerificationStatus.VERIFIED,
            'verification_status': worker.verification_status,
            'monthly_earnings': float(monthly_earnings),
            'completed_jobs_count': completed.count(),
            'pending_requests_count': pending.count(),
            'average_rating': worker.average_rating,
            'reviews_count': worker.reviews_count,
            'earnings_chart_data': weekly_data,
            'pending_requests': BookingSerializer(pending, many=True).data,
            'active_jobs': BookingSerializer(active, many=True).data,
        })


class AdminDashboardView(APIView):
    permission_classes = [IsAdminUserRole]

    def get(self, request):
        completed = Booking.objects.filter(booking_status=Booking.Status.COMPLETED)
        revenue = completed.aggregate(total=Sum('estimate_amount'))['total'] or 0

        now = timezone.localtime()
        booking_volume = []
        worker_onboarding = []
        for offset in range(6, -1, -1):
            day = (now - timedelta(days=offset)).date()
            booking_volume.append(Booking.objects.filter(created_at__date=day).count())
            worker_onboarding.append(Worker.objects.filter(created_at__date=day).count())

        pending_workers = Worker.objects.filter(
            verification_status=Worker.VerificationStatus.PENDING
        ).order_by('created_at')

        return Response({
            'total_customers': Customer.objects.count(),
            'total_workers': Worker.objects.count(),
            'verified_workers': Worker.objects.filter(verification_status=Worker.VerificationStatus.VERIFIED).count(),
            'pending_verifications_count': pending_workers.count(),
            'total_bookings': Booking.objects.count(),
            'total_revenue': float(revenue),
            'booking_volume_trend': booking_volume,
            'worker_onboarding_trend': worker_onboarding,
            'pending_workers': WorkerSerializer(pending_workers, many=True).data,
            'audit_log': [],
        })
